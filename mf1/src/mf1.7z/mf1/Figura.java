package mf1;

public interface Figura {
	public int iloscKrawedzi();
	
	public int iloscWierzcholkow();
	
}
