
public class Watki {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Watek w1 = new Watek(1); //utworzenie nowego obiektu typu Watek
        Watek w2 = new Watek(2); //utworzenie drugiego nowego obiektu typu Watek
        
        w1.start(); //uruchomienie watku 1
        w2.start(); //uruchomienie watku 2
    }
    
}
